package bg.sofia.uni.fmi.mjt.newsfeed.enums;

public enum Category {
    business, entertainment, general, health, science, sports, technology;

    @Override
    public String toString() {
        return "&category=" + name();
    }
}
