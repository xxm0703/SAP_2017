package bg.sofia.uni.fmi.mjt.newsfeed;

import bg.sofia.uni.fmi.mjt.newsfeed.enums.Category;
import bg.sofia.uni.fmi.mjt.newsfeed.enums.Country;
import bg.sofia.uni.fmi.mjt.newsfeed.exceptions.PageOutOfBoundsException;

public class Url {
    private final String API_ENDPOINT = "https://newsapi.org/v2/top-headlines?pageSize=50";
    private final String API_KEY = "&apiKey=0cde5385fb34480d87688f0b9267e8cb";
    // required parameters
    private final String keyWords;
    private int page = 1;

    // optional parameters
    private final Category category;
    private final Country country;

    private Url(UrlBuilder builder) {
        this.keyWords = builder.keyWords;
        this.country = builder.country;
        this.category = builder.category;
        if (builder.page != 0)
            this.page = builder.page;
    }

    public void nextPage() {
        if (++this.page > 3)
            throw new PageOutOfBoundsException("No next page to 3th page");
    }

    public String getKeyWords() {
        return keyWords;
    }

    public Category getCategory() {
        return category;
    }

    public Country getCountry() {
        return country;
    }

    public int getPage() {
        return page;
    }

    @Override
    public String toString() {
        var str = new StringBuilder(API_ENDPOINT)
                .append(API_KEY)
                .append("&q=")
                .append(keyWords)
                .append("&page=")
                .append(page);

        if (country != null) {
            str.append(country);
        }
        if (category != null)
            str.append(category);
        return str.toString();
    }

    public static UrlBuilder builder(String keyWords) {
        return new UrlBuilder(keyWords);
    }


    // Builder Class
    public static class UrlBuilder {

        // required parameters
        private final String keyWords;

        // optional parameters
        private Category category;
        private Country country;
        private int page;

        private UrlBuilder(String keyWords) {
            this.keyWords = keyWords;
        }

        public UrlBuilder setCountry(Country country) {
            this.country = country;
            return this;
        }

        public UrlBuilder setCategory(Category category) {
            this.category = category;
            return this;
        }

        public UrlBuilder setPage(int page) {
            if (page > 3)
                throw new PageOutOfBoundsException("Max page is 3");
            this.page = page;
            return this;
        }

        public Url build() {
            return new Url(this);
        }

    }

}
