package bg.sofia.uni.fmi.mjt.newsfeed.dto;

public interface ResponseDto {
    String show();
}
