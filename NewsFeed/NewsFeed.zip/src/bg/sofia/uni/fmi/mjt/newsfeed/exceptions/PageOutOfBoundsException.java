package bg.sofia.uni.fmi.mjt.newsfeed.exceptions;

public class PageOutOfBoundsException extends IndexOutOfBoundsException{
    public PageOutOfBoundsException(String s) {
        super(s);
    }
}
